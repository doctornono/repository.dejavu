# -*- coding: utf-8 -*-
"""Route plugin://plugin.video.dejavu/?action=… to a listing or a dialog action."""

from urllib.parse import parse_qsl

from . import actions, listing
from .plugin import log

# Dialogs / writes: do not build a directory (they call endOfDirectory themselves).
DIALOG_ACTIONS = {
    "connect": actions.connect,
    "logout": actions.logout,
    "import_kodi": actions.import_kodi,
    "settings": actions.open_settings,
    "add_player": actions.add_player,
    "remove_player": actions.remove_player,
    "set_default_player": actions.set_default_player,
    "play": actions.play,
    "toggle_watchlist": actions.toggle_watchlist,
    "toggle_favorites": actions.toggle_favorites,
    "toggle_watched": actions.toggle_watched,
}

LIST_ACTIONS = {
    "": listing.show_home,
    "home": listing.show_home,
    "profile": listing.show_profile,
    "dashboard": listing.show_dashboard,
    "dashboard_widget": listing.show_dashboard_widget,
    "history": listing.show_history,
    "watchlist": listing.show_watchlist,
    "favorites": listing.show_favorites,
    "collection": listing.show_collection,
    "ratings": listing.show_ratings,
    "lists": listing.show_lists,
    "list_items": listing.show_list_items,
    "up_next": listing.show_up_next,
    "scrobbles": listing.show_scrobbles,
    "overlay_demo": listing.show_overlay_demo,
}


def _parse_argv(argv):
    handle = int(argv[1]) if len(argv) > 1 else -1
    query = argv[2][1:] if len(argv) > 2 and argv[2].startswith("?") else (argv[2] if len(argv) > 2 else "")
    params = dict(parse_qsl(query, keep_blank_values=True))
    return handle, params


def dispatch(argv):
    handle, params = _parse_argv(argv)
    action = params.get("action") or ""
    log("action=%s params=%s" % (action, params))

    if action in DIALOG_ACTIONS:
        DIALOG_ACTIONS[action](handle, params)
        return

    view = LIST_ACTIONS.get(action)
    if view:
        view(handle, params)
        return

    log("Unknown action: %s" % action)
    listing.show_home(handle, params)
