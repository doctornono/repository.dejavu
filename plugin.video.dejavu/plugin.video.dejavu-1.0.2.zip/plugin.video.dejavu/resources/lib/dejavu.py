# -*- coding: utf-8 -*-
"""
Copy-paste helper: talk to script.dejavu from another addon.

This is the integration surface documented in script.dejavu/README.md.
Do not call https://dejavu.plus from your addon. Do not copy api_client.py.
"""

import xbmc


def user_display_name(user):
    """Best-effort label from a get_me() user dict."""
    if not isinstance(user, dict):
        return ""
    return (
        user.get("name")
        or user.get("username")
        or user.get("displayName")
        or user.get("email")
        or ""
    )


def auth_state(timeout=5):
    """
    How to know if the user is connected — copy this.

    Source of truth: the script.dejavu *service*, via RPC.

        dv = get_dejavu()
        if dv and dv.is_authenticated():
            me = dv.get_me()   # profile + stats

    `is_authenticated()` is a bool. It is False when the user is logged out,
    *and* when the 5s RPC times out (service not running). This helper
    keeps those cases apart so the UI can say "not connected" vs "timeout".

    Returns a dict:
      installed      — script.dejavu is present
      reachable      — RPC answered (None if addon missing)
      authenticated  — logged in on dejaVu.plus
      name           — display name if authenticated
      user           — get_me() user dict
      client         — DejaVuClient or None
    """
    if not xbmc.getCondVisibility("System.HasAddon(script.dejavu)"):
        return {
            "installed": False,
            "reachable": False,
            "authenticated": False,
            "name": "",
            "user": {},
            "client": None,
        }

    dv = get_dejavu(timeout=timeout)
    if not dv:
        return {
            "installed": True,
            "reachable": False,
            "authenticated": False,
            "name": "",
            "user": {},
            "client": None,
        }

    raw = dv.call("is_authenticated", {})
    if raw is None:
        return {
            "installed": True,
            "reachable": False,
            "authenticated": False,
            "name": "",
            "user": {},
            "client": dv,
        }

    authenticated = bool(raw.get("authenticated"))
    user = {}
    name = ""
    if authenticated:
        user, _stats = unwrap_me(dv.get_me() or {})
        name = user_display_name(user) or "?"
    return {
        "installed": True,
        "reachable": True,
        "authenticated": authenticated,
        "name": name,
        "user": user,
        "client": dv,
    }


def get_dejavu(timeout=5):
    """
    Return a DejaVuClient, or None if script.dejavu is missing.

    Guard the import so your addon still runs without dejaVu.
    Use timeout=8 for large get_media_status batches.
    """
    if not xbmc.getCondVisibility("System.HasAddon(script.dejavu)"):
        return None
    try:
        from client import DejaVuClient
        return DejaVuClient(timeout=timeout)
    except Exception:
        return None


def dejavu_flags(status, media_type, tmdb_id):
    """Pick data['movie:603'] (or tv:id) from a get_media_status response."""
    data = (status or {}).get("data") or {}
    if not isinstance(data, dict):
        return {}
    return data.get("%s:%s" % (media_type, tmdb_id)) or {}


def unwrap_data(result):
    """Return the `data` payload from a v1 `{success, data}` envelope."""
    if isinstance(result, dict) and "data" in result:
        return result.get("data")
    return result


def unwrap_list(result):
    """
    Normalize paginated RPC responses to (items, pagination).

    Full list payloads are already shaped for Kodi ListItems
    (info.title, art.poster, tmdbId, imdbId, …).
    """
    pagination = {}
    if not isinstance(result, dict):
        return [], pagination
    pagination = result.get("pagination") or {}
    data = result.get("data") if "data" in result else result
    if isinstance(data, list):
        return data, pagination
    if not isinstance(data, dict):
        return [], pagination
    pagination = data.get("pagination") or pagination
    for key in ("items", "results", "widgets", "lists", "history",
                "movies", "shows", "entries", "scrobbles"):
        value = data.get(key)
        if isinstance(value, list):
            return value, pagination
    inner = data.get("data")
    if isinstance(inner, list):
        return inner, pagination
    return [], pagination


def unwrap_me(result):
    """Return (user_dict, stats_dict) from get_me()."""
    if not isinstance(result, dict):
        return {}, {}
    user = result.get("user")
    stats = result.get("stats")
    data = result.get("data") if isinstance(result.get("data"), dict) else {}
    if not user:
        user = data.get("user") or data
    if not stats:
        stats = data.get("stats") or {}
    if not isinstance(user, dict):
        user = {}
    if not isinstance(stats, dict):
        stats = {}
    return user, stats


def rpc_ok(result):
    if result is None:
        return False
    if isinstance(result, dict) and result.get("success") is False:
        return False
    return True
