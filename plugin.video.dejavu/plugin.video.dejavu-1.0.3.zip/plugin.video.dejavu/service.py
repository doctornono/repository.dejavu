# -*- coding: utf-8 -*-
"""
Background monitor: when script.dejavu broadcasts a change (rate, watchlist,
login, scrobble, …), refresh this plugin's container if it is on screen.

Copy this pattern if your addon paints overlays from get_media_status.
"""

import json
import xbmc

ADDON_ID = "plugin.video.dejavu"


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f"[plugin.video.dejavu] {msg}", level)


class DejaVuDemoMonitor(xbmc.Monitor):
    def onNotification(self, sender, method, data):
        if "script.dejavu.changed" not in method:
            return
        path = xbmc.getInfoLabel("Container.FolderPath") or ""
        plugin = xbmc.getInfoLabel("Container.PluginName") or ""
        if plugin != ADDON_ID and ADDON_ID not in path and "plugin://%s" % ADDON_ID not in path:
            return
        try:
            payload = json.loads(data) if data else {}
        except Exception:
            payload = {}
        _log("script.dejavu.changed %s — Container.Refresh" % payload.get("action"))
        xbmc.executebuiltin("Container.Refresh()")


if __name__ == "__main__":
    monitor = DejaVuDemoMonitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
