# dejaVu Demo for Kodi

Proof of concept for addon developers who want to integrate [`script.dejavu`](https://dejavu.plus) into **vStream**, **AlkoFlix**, a skin, or any other Kodi addon.

Addon id: `plugin.video.dejavu` (Kodi 19+ / Python 3).

This plugin **never** talks to `https://dejavu.plus/api/v1`. It only uses `DejaVuClient` (RPC via `script.dejavu`). It is **not** a scraper and does not provide streams.

Depends on **`script.dejavu` ≥ 1.7.5**.

## What this addon demonstrates

| Screen / action | RPC / helper |
|---|---|
| Account | `script.dejavu` settings (`access_token` / `username`) — not a second login |
| Sign in / manage account | `RunScript(script.dejavu,action=login)` / `Addon.OpenSettings(script.dejavu)` |
| Import Kodi library | `RunScript(script.dejavu,action=import_kodi)` |
| Profile | `get_me()` |
| Dashboard | `get_dashboard()` then `get_dashboard_widget()` |
| History, watchlist, favorites, collection, ratings | `get_history` / `get_watchlist` / `get_favorites` / `get_collection` / `get_ratings` |
| Custom lists | `get_lists` / `get_list_items` |
| Continue watching / Up next | `get_scrobbles` / `get_up_next` |
| Overlay demo | `get_media_status` in batches of 50 |
| Watched checkmark on rows | Kodi `playcount` + overlay from those flags |
| Context submenu **dejaVu** | `UniqueID(tmdb)` + properties `tmdb_id` / `TmdbId` / `imdb_id` |
| Play | Hands off to a configured player (vStream, AlkoFlix, …) |

Copy [`resources/lib/dejavu.py`](resources/lib/dejavu.py) into your addon. That file is the integration surface.

## How to know if the user is connected

**One session**, in `script.dejavu` — the same as Trakt. This demo does not have its own login.

```python
import xbmc
import xbmcaddon

script = xbmcaddon.Addon("script.dejavu")
if script.getSetting("access_token"):
    name = script.getSetting("username")   # already logged in
    dv = get_dejavu()
    history = dv.get_history()             # RPC for data, not for auth
else:
    xbmc.executebuiltin("RunScript(script.dejavu,action=login)")
```

`auth_state()` in [`resources/lib/dejavu.py`](resources/lib/dejavu.py) wraps that. The home screen reads the token locally (no 8s wait).

`is_authenticated()` RPC is optional. A timeout must **not** be treated as logout.

The first row of the demo:

| First row | Meaning |
|---|---|
| green **Connected as …** | `access_token` set in script.dejavu |
| grey **Not connected** | no token — open script.dejavu to sign in |
| red **not installed** | `script.dejavu` missing |

Settings of this demo only show the status and **Open dejaVu settings**.

## Install

1. Install `script.dejavu` (and log in).
2. Install this addon from ZIP or from the dejaVu repository.
3. Open **dejaVu Demo** from the video addons list.
4. **Settings → Players → Add a player** and pick vStream, AlkoFlix, or any other video plugin.

## Copy-paste: client helper

```python
import xbmc

def get_dejavu(timeout=5):
    if not xbmc.getCondVisibility("System.HasAddon(script.dejavu)"):
        return None
    try:
        from client import DejaVuClient
        return DejaVuClient(timeout=timeout)
    except Exception:
        return None
```

In `addon.xml`:

```xml
<requires>
    <import addon="xbmc.python" version="3.0.0"/>
    <import addon="script.dejavu" version="1.7.5"/>
</requires>
```

Fail soft: missing addon or logged-out user → no badges, UI still works.

## Copy-paste: watched overlay (batch)

This is the advanced Kodi integration: ask dejaVu if the user already saw the title, then paint Kodi's native watched state.

```python
dv = get_dejavu(timeout=8)
status = dv.get_media_status([
    {"type": "movie", "id": 603},
    {"type": "tv", "id": 1396},
])
data = (status or {}).get("data") or {}
flags = data.get("movie:603") or {}

info = {"title": title, "mediatype": "movie"}
if flags.get("watched"):
    info["playcount"] = 1
    info["overlay"] = 5  # watched
else:
    info["playcount"] = 0
    info["overlay"] = 4  # unwatched

listitem.setInfo("video", info)
listitem.setUniqueIDs({"tmdb": "603"}, "tmdb")
listitem.setProperty("tmdb_id", "603")
listitem.setProperty("TmdbId", "603")
```

Rules:

- `type` is `"movie"` or `"tv"` only. For an episode, pass the **show** TMDB id as `"tv"`.
- Batch in chunks of **50**. Use `timeout=8` on large pages.
- Listen for `script.dejavu.changed` and call `Container.Refresh()` (see `service.py`).

Library mirroring (`VideoLibrary.SetMovieDetails`) stays inside `script.dejavu`. Do not duplicate it.

## Players

Settings store a JSON list of video addon ids.

- **vStream** (`plugin.video.vstream`): native global search  
  `plugin://plugin.video.vstream/?function=searchMovie&site=globalSearch&sCat=1&searchtext=…`  
  (`sCat=1` movies, `sCat=2` shows).
- **Any other addon** (AlkoFlix, …): generic contract

```
plugin://{addon_id}/?action=dejavu_play&type=movie&tmdb_id=603
    &imdb_id=tt0133093&title=The+Matrix&year=1999
```

Implement `action=dejavu_play` in your player, or add an adapter in [`resources/lib/players.py`](resources/lib/players.py). This demo does not scrape and does not scrobble: `script.dejavu` already hooks the Kodi player.

## Layout of this addon (what to copy)

| File | Role |
|---|---|
| `resources/lib/dejavu.py` | `get_dejavu()` / unwrap helpers |
| `resources/lib/items.py` | ListItem + `get_media_status` overlays |
| `resources/lib/listing.py` | One function per RPC listing |
| `resources/lib/players.py` | Player registry + URL adapters |
| `resources/lib/actions.py` | Connect, import, toggles, play |
| `service.py` | `script.dejavu.changed` → refresh |

Full RPC catalogue: `script.dejavu/README.md` and `script.dejavu/FONCTIONNALITES.md`.

## License

MIT — see [LICENSE.txt](LICENSE.txt).
