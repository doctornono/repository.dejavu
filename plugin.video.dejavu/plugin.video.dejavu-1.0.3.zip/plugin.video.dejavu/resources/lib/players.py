# -*- coding: utf-8 -*-
"""
External players (vStream, AlkoFlix, or any video plugin).

Settings store a JSON list of addon ids. Playback never scrapes here:
we hand the title to another addon. script.dejavu still scrobbles via
Kodi player hooks.

Generic URL contract (implement this in your player addon):

  plugin://{addon_id}/?action=dejavu_play&type=movie&tmdb_id=603
      &imdb_id=tt0133093&title=The+Matrix&year=1999

Known adapters:
  plugin.video.vstream — native global search (function=searchMovie).
"""

import json
import xbmc
import xbmcgui

from .plugin import ADDON, ADDON_ID, log, ls, notify

SELF_IDS = {ADDON_ID, "script.dejavu"}


def _jsonrpc(method, params, req_id=1):
    payload = json.dumps({
        "jsonrpc": "2.0",
        "method": method,
        "params": params,
        "id": req_id,
    })
    try:
        return json.loads(xbmc.executeJSONRPC(payload))
    except Exception as exc:
        log("JSON-RPC %s failed: %s" % (method, exc))
        return {}


def load_players():
    raw = ADDON.getSetting("players_json") or "[]"
    try:
        players = json.loads(raw)
    except Exception:
        players = []
    if not isinstance(players, list):
        players = []
    cleaned = []
    for entry in players:
        if isinstance(entry, dict) and entry.get("id"):
            cleaned.append({
                "id": str(entry["id"]),
                "name": entry.get("name") or str(entry["id"]),
            })
        elif isinstance(entry, str) and entry:
            cleaned.append({"id": entry, "name": entry})
    return cleaned


def save_players(players):
    ADDON.setSetting("players_json", json.dumps(players, ensure_ascii=False))
    names = [p.get("name") or p.get("id") for p in players]
    ADDON.setSetting("players_display", ", ".join(names))
    default = ADDON.getSetting("default_player") or ""
    ids = [p["id"] for p in players]
    if default and default not in ids:
        ADDON.setSetting("default_player", ids[0] if ids else "")
    elif not default and ids:
        ADDON.setSetting("default_player", ids[0])


def default_player_id():
    default = ADDON.getSetting("default_player") or ""
    ids = [p["id"] for p in load_players()]
    if default in ids:
        return default
    return ids[0] if ids else ""


def installed_video_addons():
    """Installed, enabled video plugins — what the user can add as a player."""
    result = _jsonrpc("Addons.GetAddons", {
        "type": "xbmc.python.pluginsource",
        "content": "video",
        "enabled": True,
        "properties": ["name"],
    })
    addons = ((result.get("result") or {}).get("addons") or [])
    out = []
    for addon in addons:
        addon_id = addon.get("addonid") or addon.get("id")
        if not addon_id or addon_id in SELF_IDS:
            continue
        out.append({
            "id": addon_id,
            "name": addon.get("name") or addon_id,
        })
    out.sort(key=lambda item: item["name"].lower())
    return out


def add_player_dialog():
    candidates = installed_video_addons()
    existing = {p["id"] for p in load_players()}
    candidates = [c for c in candidates if c["id"] not in existing]
    if not candidates:
        notify(ls(30016), error=True)
        return
    labels = ["%s  (%s)" % (c["name"], c["id"]) for c in candidates]
    choice = xbmcgui.Dialog().select(ls(30012), labels)
    if choice < 0:
        return
    chosen = candidates[choice]
    players = load_players()
    players.append(chosen)
    save_players(players)
    notify(ls(30017) % chosen["name"])
    ADDON.openSettings()


def remove_player_dialog():
    players = load_players()
    if not players:
        notify(ls(30085), error=True)
        return
    labels = ["%s  (%s)" % (p["name"], p["id"]) for p in players]
    choice = xbmcgui.Dialog().select(ls(30013), labels)
    if choice < 0:
        return
    removed = players.pop(choice)
    save_players(players)
    notify(ls(30018) % removed["name"])
    ADDON.openSettings()


def set_default_player_dialog():
    players = load_players()
    if not players:
        notify(ls(30085), error=True)
        return
    labels = ["%s  (%s)" % (p["name"], p["id"]) for p in players]
    current = default_player_id()
    preselect = 0
    for idx, player in enumerate(players):
        if player["id"] == current:
            preselect = idx
            break
    try:
        choice = xbmcgui.Dialog().select(ls(30014), labels, preselect=preselect)
    except TypeError:
        choice = xbmcgui.Dialog().select(ls(30014), labels)
    if choice < 0:
        return
    ADDON.setSetting("default_player", players[choice]["id"])
    notify(ls(30025) % players[choice]["name"])
    ADDON.openSettings()


def _vstream_url(item):
    from urllib.parse import quote_plus
    title = item.get("title") or ""
    media_type = (item.get("media_type") or item.get("type") or "movie").lower()
    scat = "2" if media_type in ("tv", "tvshow", "episode") else "1"
    return (
        "plugin://plugin.video.vstream/"
        "?function=searchMovie&site=globalSearch&sCat=%s&searchtext=%s"
        % (scat, quote_plus(title))
    )


def player_url(addon_id, item):
    """Map a media dict to a plugin:// URL for the chosen player."""
    if addon_id == "plugin.video.vstream":
        return _vstream_url(item)
    from urllib.parse import urlencode
    params = {
        "action": "dejavu_play",
        "type": item.get("media_type") or item.get("type") or "movie",
        "tmdb_id": item.get("tmdb_id") or "",
        "imdb_id": item.get("imdb_id") or "",
        "title": item.get("title") or "",
        "year": item.get("year") or "",
    }
    if item.get("season") is not None and item.get("season") != "":
        params["season"] = item["season"]
    if item.get("episode") is not None and item.get("episode") != "":
        params["episode"] = item["episode"]
    if item.get("show_tmdb_id"):
        params["tv_show_id"] = item["show_tmdb_id"]
    return "plugin://%s/?%s" % (addon_id, urlencode(params))


def pick_player(force_select=False):
    players = load_players()
    if not players:
        notify(ls(30020), error=True)
        return None
    if not force_select and len(players) == 1:
        return players[0]
    if not force_select:
        default = default_player_id()
        for player in players:
            if player["id"] == default:
                return player
        return players[0]
    labels = ["%s  (%s)" % (p["name"], p["id"]) for p in players]
    choice = xbmcgui.Dialog().select(ls(30070), labels)
    if choice < 0:
        return None
    return players[choice]


def play_item(params, force_select=False):
    player = pick_player(force_select=force_select)
    if not player:
        return False
    item = {
        "media_type": params.get("type") or "movie",
        "tmdb_id": params.get("tmdb_id") or "",
        "imdb_id": params.get("imdb_id") or "",
        "title": params.get("title") or "",
        "year": params.get("year") or "",
        "season": params.get("season") or "",
        "episode": params.get("episode") or "",
        "show_tmdb_id": params.get("show_tmdb_id") or "",
    }
    url = player_url(player["id"], item)
    log("Launch player %s → %s" % (player["id"], url))
    xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % url)
    return True
