# -*- coding: utf-8 -*-
"""
ListItem builder + get_media_status overlays.

Advanced Kodi integration shown here:
  1. Batch get_media_status (max 50) for the current page.
  2. Set playcount / overlay so skins draw the native watched checkmark.
  3. Set UniqueID(tmdb) + tmdb_id / TmdbId / imdb_id so script.dejavu's
     context submenu is visible on these rows.
"""

import xbmcgui
import xbmcplugin

from .dejavu import dejavu_flags, get_dejavu
from .plugin import (
    addon_fanart,
    addon_icon,
    log,
    ls,
    plugin_url,
    setting_bool,
)

# Kodi video overlay icons (still honoured by many skins via playcount).
OVERLAY_UNWATCHED = 4
OVERLAY_WATCHED = 5

TV_TYPES = ("tv", "tvshow", "show", "series")
EPISODE_TYPES = ("episode",)


def _as_int(value):
    if value is None or value == "":
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        text = str(value).strip()
        return int(text) if text.isdigit() else None


def normalize_media(raw):
    """Flatten a dejaVu list/widget payload into one dict this addon understands."""
    if not isinstance(raw, dict):
        return None
    info = raw.get("info") if isinstance(raw.get("info"), dict) else {}
    art = raw.get("art") if isinstance(raw.get("art"), dict) else {}

    tmdb_id = (
        raw.get("tmdbId") or raw.get("tmdb_id") or info.get("tmdbId")
        or info.get("tmdb_id")
    )
    # `id` is TMDB on most list payloads; skip UUID-looking list ids.
    if tmdb_id is None:
        raw_id = raw.get("id")
        if raw_id is not None and str(raw_id).isdigit():
            tmdb_id = raw_id

    imdb_id = (
        raw.get("imdbId") or raw.get("imdb_id") or info.get("imdbnumber")
        or info.get("imdb") or info.get("imdbId")
    )
    media_type = (
        raw.get("type") or info.get("mediatype") or info.get("type") or "movie"
    )
    media_type = str(media_type).lower()
    if media_type in ("movie", "movies"):
        media_type = "movie"
    elif media_type in TV_TYPES:
        media_type = "tv"
    elif media_type in EPISODE_TYPES:
        media_type = "episode"

    title = (
        info.get("title") or raw.get("title") or raw.get("name")
        or info.get("originaltitle") or ""
    )
    plot = info.get("plot") or info.get("overview") or raw.get("overview") or ""
    year = info.get("year") or raw.get("year")
    poster = (
        art.get("poster") or art.get("thumb") or raw.get("posterUrl")
        or raw.get("poster") or ""
    )
    fanart = (
        art.get("fanart") or art.get("backdrop") or raw.get("backdropUrl")
        or raw.get("fanart") or ""
    )
    show_tmdb = (
        raw.get("tvShowId") or raw.get("showTmdbId") or raw.get("show_tmdb_id")
        or info.get("tvshow.tmdb") or info.get("tvShowId")
    )
    season = raw.get("seasonNumber") or raw.get("season") or info.get("season")
    episode = raw.get("episodeNumber") or raw.get("episode") or info.get("episode")
    # Overlay batch is movie|tv only. Episodes overlay the *show*.
    if media_type == "episode":
        overlay_type, overlay_id = "tv", _as_int(show_tmdb) or _as_int(tmdb_id)
    elif media_type == "tv":
        overlay_type, overlay_id = "tv", _as_int(show_tmdb) or _as_int(tmdb_id)
    else:
        overlay_type, overlay_id = "movie", _as_int(tmdb_id)

    kodi_dbtype = "movie"
    if media_type == "tv":
        kodi_dbtype = "tvshow"
    elif media_type == "episode":
        kodi_dbtype = "episode"

    return {
        "tmdb_id": _as_int(tmdb_id),
        "imdb_id": str(imdb_id).strip() if imdb_id else "",
        "media_type": media_type,
        "kodi_dbtype": kodi_dbtype,
        "title": title,
        "plot": plot,
        "year": _as_int(year),
        "poster": poster,
        "fanart": fanart,
        "show_tmdb_id": _as_int(show_tmdb),
        "season": _as_int(season),
        "episode": _as_int(episode),
        "overlay_type": overlay_type,
        "overlay_id": overlay_id,
        "raw": raw,
    }


def fetch_status_map(media_items):
    """
    One or more get_media_status round-trips (chunks of 50).

    Returns a dict keyed by 'movie:603' / 'tv:1396'.
    Missing addon / timeout / logged-out → empty dict (no crash).
    """
    keys = []
    seen = set()
    for media in media_items:
        if not media:
            continue
        overlay_type = media.get("overlay_type")
        overlay_id = media.get("overlay_id")
        if overlay_type not in ("movie", "tv") or not overlay_id:
            continue
        pair = (overlay_type, int(overlay_id))
        if pair in seen:
            continue
        seen.add(pair)
        keys.append({"type": pair[0], "id": pair[1]})

    if not keys:
        return {}

    dv = get_dejavu(timeout=8)
    if not dv:
        return {}

    status_map = {}
    for start in range(0, len(keys), 50):
        chunk = keys[start:start + 50]
        result = dv.get_media_status(chunk)
        data = (result or {}).get("data") if isinstance(result, dict) else None
        if isinstance(data, dict):
            status_map.update(data)
        else:
            log("get_media_status returned nothing for %s items" % len(chunk))
    return status_map


def flags_for(status_map, media):
    if not media:
        return {}
    overlay_type = media.get("overlay_type")
    overlay_id = media.get("overlay_id")
    if not overlay_type or not overlay_id:
        return {}
    fake = {"data": status_map}
    return dejavu_flags(fake, overlay_type, overlay_id)


def badge_label(title, flags):
    if not setting_bool("show_badges", True):
        return title
    label = title or ""
    if flags.get("watched"):
        label = "[COLOR green]✔[/COLOR] " + label
    if flags.get("rating"):
        label += "  ★%s" % flags["rating"]
    if flags.get("inWatchlist"):
        label += "  [COLOR yellow]●[/COLOR]"
    if flags.get("isFavorite"):
        label += "  [COLOR red]♥[/COLOR]"
    return label


def build_listitem(media, flags=None):
    flags = flags or {}
    title = media.get("title") or ""
    label = badge_label(title, flags)
    item = xbmcgui.ListItem(label=label, offscreen=True)

    info = {
        "title": title,
        "plot": media.get("plot") or "",
        "mediatype": media.get("kodi_dbtype") or "movie",
    }
    if media.get("year"):
        info["year"] = media["year"]
    if media.get("imdb_id"):
        info["imdbnumber"] = media["imdb_id"]
    if media.get("season") is not None:
        info["season"] = media["season"]
    if media.get("episode") is not None:
        info["episode"] = media["episode"]
    if flags.get("rating"):
        try:
            info["userrating"] = int(flags["rating"])
        except (TypeError, ValueError):
            pass

    # Native Kodi "already watched" checkmark on plugin lists.
    if setting_bool("apply_playcount", True):
        watched = bool(flags.get("watched"))
        info["playcount"] = 1 if watched else 0
        info["overlay"] = OVERLAY_WATCHED if watched else OVERLAY_UNWATCHED

    item.setInfo("video", info)
    item.setArt({
        "icon": media.get("poster") or addon_icon(),
        "thumb": media.get("poster") or addon_icon(),
        "poster": media.get("poster") or addon_icon(),
        "fanart": media.get("fanart") or addon_fanart(),
    })

    tmdb_id = media.get("tmdb_id")
    show_tmdb = media.get("show_tmdb_id")
    imdb_id = media.get("imdb_id") or ""
    unique_ids = {}
    if tmdb_id:
        unique_ids["tmdb"] = str(tmdb_id)
    if imdb_id:
        unique_ids["imdb"] = imdb_id
    if unique_ids and hasattr(item, "setUniqueIDs"):
        item.setUniqueIDs(unique_ids, "tmdb" if tmdb_id else "imdb")

    # Properties required by script.dejavu context-menu visibility.
    if tmdb_id:
        item.setProperty("tmdb_id", str(tmdb_id))
        item.setProperty("TmdbId", str(tmdb_id))
    if show_tmdb:
        item.setProperty("tvshow_tmdb_id", str(show_tmdb))
        item.setProperty("TVShowID", str(show_tmdb))
    if imdb_id:
        item.setProperty("imdb_id", imdb_id)
    item.setProperty("DBType", media.get("kodi_dbtype") or "movie")
    item.setProperty("media_type", media.get("media_type") or "movie")

    item.addContextMenuItems(_context_menu(media, flags), replaceItems=False)
    return item


def _play_params(media):
    return {
        "action": "play",
        "type": media.get("media_type") or "movie",
        "tmdb_id": media.get("tmdb_id") or "",
        "imdb_id": media.get("imdb_id") or "",
        "title": media.get("title") or "",
        "year": media.get("year") or "",
        "season": media.get("season") if media.get("season") is not None else "",
        "episode": media.get("episode") if media.get("episode") is not None else "",
        "show_tmdb_id": media.get("show_tmdb_id") or "",
    }


def _context_menu(media, flags):
    commands = []
    play_params = _play_params(media)
    commands.append((ls(30051), "RunPlugin(%s)" % plugin_url(**play_params)))
    commands.append((
        ls(30052),
        "RunPlugin(%s)" % plugin_url(**dict(play_params, select_player="1")),
    ))

    overlay_type = media.get("overlay_type")
    overlay_id = media.get("overlay_id")
    if overlay_type and overlay_id:
        toggle = {
            "type": overlay_type,
            "tmdb_id": overlay_id,
            "title": media.get("title") or "",
        }
        commands.append((
            ls(30049),
            "RunPlugin(%s)" % plugin_url(action="toggle_watchlist", **toggle),
        ))
        commands.append((
            ls(30059),
            "RunPlugin(%s)" % plugin_url(action="toggle_favorites", **toggle),
        ))
        if (media.get("media_type") or "") == "movie" and media.get("tmdb_id"):
            commands.append((
                ls(30050),
                "RunPlugin(%s)" % plugin_url(
                    action="toggle_watched",
                    type="movie",
                    tmdb_id=media["tmdb_id"],
                    title=media.get("title") or "",
                ),
            ))
    return commands


def add_media_items(handle, raw_items):
    """Normalize, overlay in batch, then add directory items (click = play)."""
    media_items = []
    for raw in raw_items or []:
        media = normalize_media(raw)
        if media and (media.get("title") or media.get("tmdb_id")):
            media_items.append(media)

    status_map = fetch_status_map(media_items)
    added = 0
    for media in media_items:
        flags = flags_for(status_map, media)
        item = build_listitem(media, flags)
        url = plugin_url(**_play_params(media))
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)
        added += 1
    return added


def add_folder(handle, label, params, icon=None, plot=""):
    item = xbmcgui.ListItem(label=label, offscreen=True)
    item.setArt({
        "icon": icon or addon_icon(),
        "thumb": icon or addon_icon(),
        "fanart": addon_fanart(),
    })
    if plot:
        item.setInfo("video", {"plot": plot, "title": label})
    xbmcplugin.addDirectoryItem(handle, plugin_url(**params), item, isFolder=True)


def add_action_item(handle, label, params, plot=""):
    item = xbmcgui.ListItem(label=label, offscreen=True)
    item.setArt({"icon": addon_icon(), "thumb": addon_icon(), "fanart": addon_fanart()})
    if plot:
        item.setInfo("video", {"plot": plot, "title": label})
    xbmcplugin.addDirectoryItem(handle, plugin_url(**params), item, isFolder=False)
