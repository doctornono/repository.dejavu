# -*- coding: utf-8 -*-
"""
dejaVu Demo — plugin entry point.

This addon never talks to dejavu.plus. It only uses DejaVuClient
(RPC via script.dejavu). Copy the patterns in resources/lib/.
"""

import sys
from resources.lib.router import dispatch


if __name__ == "__main__":
    dispatch(sys.argv)
