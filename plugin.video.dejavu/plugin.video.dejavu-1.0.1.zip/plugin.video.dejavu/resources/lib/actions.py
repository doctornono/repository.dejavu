# -*- coding: utf-8 -*-
"""Dialog-style plugin actions: Connect, import, toggles, play, players."""

import xbmc
import xbmcplugin

from .dejavu import dejavu_flags, get_dejavu
from .players import (
    add_player_dialog,
    play_item,
    remove_player_dialog,
    set_default_player_dialog,
)
from .plugin import ADDON, end_directory, ls, notify


def _close_plugin(handle):
    end_directory(handle, succeeded=True, cache=False)


def _require_client(timeout=5):
    if not xbmc.getCondVisibility("System.HasAddon(script.dejavu)"):
        notify(ls(30046), error=True)
        return None
    dv = get_dejavu(timeout=timeout)
    if not dv:
        notify(ls(30046), error=True)
        return None
    return dv


def connect(handle, params):
    dv = _require_client(timeout=8)
    if not dv:
        _close_plugin(handle)
        return
    # authenticate() is NOT the 5s RPC: it launches the QR dialog and polls.
    result = dv.authenticate()
    if isinstance(result, dict) and result.get("success") is False:
        notify(ls(30054) % (result.get("error") or ""), error=True)
    else:
        notify(ls(30072))
        xbmc.executebuiltin("Container.Refresh()")
    _close_plugin(handle)


def logout(handle, params):
    dv = _require_client()
    if dv:
        dv.logout()
        notify(ls(30055))
        xbmc.executebuiltin("Container.Refresh()")
    _close_plugin(handle)


def import_kodi(handle, params):
    dv = _require_client(timeout=8)
    if not dv:
        _close_plugin(handle)
        return
    if not dv.is_authenticated():
        notify(ls(30048), error=True)
        _close_plugin(handle)
        return
    # import_kodi_library() is NOT the 5s RPC (wizard, up to 10 minutes).
    result = dv.import_kodi_library()
    if isinstance(result, dict):
        status = result.get("status") or result.get("error") or ("ok" if result.get("success") else "error")
        notify(ls(30056) % status, error=not result.get("success"))
    else:
        notify(ls(30068), error=True)
    _close_plugin(handle)


def open_settings(handle, params):
    ADDON.openSettings()
    _close_plugin(handle)


def add_player(handle, params):
    add_player_dialog()
    _close_plugin(handle)


def remove_player(handle, params):
    remove_player_dialog()
    _close_plugin(handle)


def set_default_player(handle, params):
    set_default_player_dialog()
    _close_plugin(handle)


def play(handle, params):
    force = str(params.get("select_player") or "") in ("1", "true", "True")
    play_item(params, force_select=force)
    if handle is not None and int(handle) >= 0:
        xbmcplugin.endOfDirectory(int(handle), succeeded=False)


def _single_flags(dv, media_type, tmdb_id):
    status = dv.get_media_status([{"type": media_type, "id": int(tmdb_id)}])
    return dejavu_flags(status, media_type, tmdb_id)


def toggle_watchlist(handle, params):
    dv = _require_client()
    if not dv:
        _close_plugin(handle)
        return
    media_type = params.get("type") or "movie"
    tmdb_id = params.get("tmdb_id")
    if not tmdb_id or not str(tmdb_id).isdigit():
        notify(ls(30068), error=True)
        _close_plugin(handle)
        return
    flags = _single_flags(dv, media_type, tmdb_id)
    if flags.get("inWatchlist"):
        result = dv.remove_from_watchlist(media_type, int(tmdb_id))
        notify(ls(30080) if result is not None else ls(30068), error=result is None)
    else:
        result = dv.add_to_watchlist(media_type, int(tmdb_id))
        notify(ls(30079) if result is not None else ls(30068), error=result is None)
    xbmc.executebuiltin("Container.Refresh()")
    _close_plugin(handle)


def toggle_favorites(handle, params):
    dv = _require_client()
    if not dv:
        _close_plugin(handle)
        return
    media_type = params.get("type") or "movie"
    tmdb_id = params.get("tmdb_id")
    if not tmdb_id or not str(tmdb_id).isdigit():
        notify(ls(30068), error=True)
        _close_plugin(handle)
        return
    flags = _single_flags(dv, media_type, tmdb_id)
    if flags.get("isFavorite"):
        result = dv.remove_from_favorites(media_type, int(tmdb_id))
        notify(ls(30084) if result is not None else ls(30068), error=result is None)
    else:
        result = dv.add_to_favorites(media_type, int(tmdb_id))
        notify(ls(30083) if result is not None else ls(30068), error=result is None)
    xbmc.executebuiltin("Container.Refresh()")
    _close_plugin(handle)


def toggle_watched(handle, params):
    """Movie history only — dejaVu history writes are per movie/episode, not per show."""
    dv = _require_client()
    if not dv:
        _close_plugin(handle)
        return
    tmdb_id = params.get("tmdb_id")
    if not tmdb_id or not str(tmdb_id).isdigit():
        notify(ls(30068), error=True)
        _close_plugin(handle)
        return
    flags = _single_flags(dv, "movie", tmdb_id)
    if flags.get("watched"):
        result = dv.delete_history("movie", int(tmdb_id))
        notify(ls(30082) if result is not None else ls(30068), error=result is None)
    else:
        result = dv.add_to_history("movie", tmdb_id=int(tmdb_id))
        notify(ls(30081) if result is not None else ls(30068), error=result is None)
    xbmc.executebuiltin("Container.Refresh()")
    _close_plugin(handle)
