# -*- coding: utf-8 -*-
"""Shared Kodi helpers for this demo addon."""

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from urllib.parse import urlencode

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name") or "dejaVu Demo"


def ls(string_id):
    return ADDON.getLocalizedString(string_id)


def debug_enabled():
    return ADDON.getSetting("debug") == "true"


def log(msg, level=None):
    if level is None:
        level = xbmc.LOGINFO if debug_enabled() else xbmc.LOGDEBUG
    xbmc.log(f"[{ADDON_ID}] {msg}", level)


def notify(message, error=False, time_ms=4000):
    icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification(ADDON_NAME, message, icon, time_ms)


def setting_bool(key, default=True):
    raw = ADDON.getSetting(key)
    if raw == "":
        return default
    return raw == "true"


def page_size():
    try:
        size = int(ADDON.getSetting("page_size") or "20")
    except ValueError:
        size = 20
    return max(1, min(size, 50))


def plugin_url(**kwargs):
    """Build a plugin:// URL for this addon. Skip empty values."""
    params = {}
    for key, value in kwargs.items():
        if value is None or value == "":
            continue
        params[key] = str(value)
    return "plugin://%s/?%s" % (ADDON_ID, urlencode(params))


def end_directory(handle, succeeded=True, content="videos", cache=False):
    if handle is None or int(handle) < 0:
        return
    try:
        xbmcplugin.setContent(int(handle), content)
    except Exception:
        pass
    xbmcplugin.endOfDirectory(int(handle), succeeded=succeeded, cacheToDisc=cache)


def addon_icon():
    return ADDON.getAddonInfo("icon") or ""


def addon_fanart():
    return ADDON.getAddonInfo("fanart") or ""
