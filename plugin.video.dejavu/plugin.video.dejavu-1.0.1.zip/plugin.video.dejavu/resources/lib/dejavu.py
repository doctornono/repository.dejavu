# -*- coding: utf-8 -*-
"""
Copy-paste helper: talk to script.dejavu from another addon.

This is the integration surface documented in script.dejavu/README.md.
Do not call https://dejavu.plus from your addon. Do not copy api_client.py.
"""

import xbmc


def get_dejavu(timeout=5):
    """
    Return a DejaVuClient, or None if script.dejavu is missing.

    Guard the import so your addon still runs without dejaVu.
    Use timeout=8 for large get_media_status batches.
    """
    if not xbmc.getCondVisibility("System.HasAddon(script.dejavu)"):
        return None
    try:
        from client import DejaVuClient
        return DejaVuClient(timeout=timeout)
    except Exception:
        return None


def dejavu_flags(status, media_type, tmdb_id):
    """Pick data['movie:603'] (or tv:id) from a get_media_status response."""
    data = (status or {}).get("data") or {}
    if not isinstance(data, dict):
        return {}
    return data.get("%s:%s" % (media_type, tmdb_id)) or {}


def unwrap_data(result):
    """Return the `data` payload from a v1 `{success, data}` envelope."""
    if isinstance(result, dict) and "data" in result:
        return result.get("data")
    return result


def unwrap_list(result):
    """
    Normalize paginated RPC responses to (items, pagination).

    Full list payloads are already shaped for Kodi ListItems
    (info.title, art.poster, tmdbId, imdbId, …).
    """
    pagination = {}
    if not isinstance(result, dict):
        return [], pagination
    pagination = result.get("pagination") or {}
    data = result.get("data") if "data" in result else result
    if isinstance(data, list):
        return data, pagination
    if not isinstance(data, dict):
        return [], pagination
    pagination = data.get("pagination") or pagination
    for key in ("items", "results", "widgets", "lists", "history",
                "movies", "shows", "entries", "scrobbles"):
        value = data.get(key)
        if isinstance(value, list):
            return value, pagination
    inner = data.get("data")
    if isinstance(inner, list):
        return inner, pagination
    return [], pagination


def unwrap_me(result):
    """Return (user_dict, stats_dict) from get_me()."""
    if not isinstance(result, dict):
        return {}, {}
    user = result.get("user")
    stats = result.get("stats")
    data = result.get("data") if isinstance(result.get("data"), dict) else {}
    if not user:
        user = data.get("user") or data
    if not stats:
        stats = data.get("stats") or {}
    if not isinstance(user, dict):
        user = {}
    if not isinstance(stats, dict):
        stats = {}
    return user, stats


def rpc_ok(result):
    if result is None:
        return False
    if isinstance(result, dict) and result.get("success") is False:
        return False
    return True
