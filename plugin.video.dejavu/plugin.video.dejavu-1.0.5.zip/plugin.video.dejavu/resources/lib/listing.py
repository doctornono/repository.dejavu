# -*- coding: utf-8 -*-
"""
Directory listings mapped 1:1 to DejaVuClient RPC methods.

Each screen is a copy-paste example: get client → call RPC → add ListItems.
"""

import xbmc

from .dejavu import auth_state, get_dejavu, unwrap_data, unwrap_list, unwrap_me
from .items import add_action_item, add_folder, add_media_items
from .plugin import end_directory, ls, notify, page_size, sync_account_settings

SKIP_WIDGET_TYPES = {"stats"}

# Sample TMDB ids so get_media_status can be tried even on an empty account.
DEMO_TITLES = [
    {"type": "movie", "tmdbId": 603, "title": "The Matrix", "year": 1999,
     "info": {"title": "The Matrix", "year": 1999, "mediatype": "movie", "plot": "TMDB 603 — overlay demo"}},
    {"type": "movie", "tmdbId": 27205, "title": "Inception", "year": 2010,
     "info": {"title": "Inception", "year": 2010, "mediatype": "movie", "plot": "TMDB 27205 — overlay demo"}},
    {"type": "movie", "tmdbId": 155, "title": "The Dark Knight", "year": 2008,
     "info": {"title": "The Dark Knight", "year": 2008, "mediatype": "movie", "plot": "TMDB 155 — overlay demo"}},
    {"type": "tv", "tmdbId": 1396, "title": "Breaking Bad", "year": 2008,
     "info": {"title": "Breaking Bad", "year": 2008, "mediatype": "tvshow", "plot": "TMDB 1396 — overlay demo"}},
    {"type": "tv", "tmdbId": 1399, "title": "Game of Thrones", "year": 2011,
     "info": {"title": "Game of Thrones", "year": 2011, "mediatype": "tvshow", "plot": "TMDB 1399 — overlay demo"}},
]


def _page(params):
    try:
        return max(1, int(params.get("page") or 1))
    except ValueError:
        return 1


def _client(handle, need_auth=True):
    if not xbmc.getCondVisibility("System.HasAddon(script.dejavu)"):
        notify(ls(30046), error=True)
        add_action_item(handle, ls(30062), {"action": "open_dejavu"})
        end_directory(handle)
        return None
    state = auth_state()
    sync_account_settings(state)
    if need_auth and not state["authenticated"]:
        notify(ls(30047), error=True)
        add_action_item(handle, ls(30001), {"action": "open_dejavu"}, plot=ls(30091))
        end_directory(handle)
        return None
    dv = state.get("client") or get_dejavu(timeout=8)
    if not dv:
        notify(ls(30046), error=True)
        end_directory(handle)
        return None
    return dv


def _next_page_folder(handle, params, pagination):
    if not pagination.get("hasMore"):
        return
    next_params = dict(params)
    next_params["page"] = int(pagination.get("page") or _page(params)) + 1
    add_folder(handle, ls(30044), next_params)


def _media_page(handle, result, next_params):
    if result is None:
        notify(ls(30068), error=True)
        end_directory(handle)
        return
    items, pagination = unwrap_list(result)
    add_media_items(handle, items)
    _next_page_folder(handle, next_params, pagination)
    end_directory(handle)


def _status_label(state):
    """First row: script.dejavu session (token), not a second login."""
    if not state.get("installed"):
        return "[COLOR red]%s[/COLOR]" % ls(30046)
    if state.get("authenticated"):
        return "[COLOR green]● %s[/COLOR]" % (ls(30087) % (state.get("name") or "?"))
    return "[COLOR grey]○ %s[/COLOR]" % ls(30088)


def show_home(handle, params):
    # Instant: read script.dejavu access_token / username. No auth RPC.
    state = auth_state()
    sync_account_settings(state)

    add_action_item(
        handle,
        _status_label(state),
        {"action": "open_dejavu"},
        plot=ls(30090),
    )

    if state["authenticated"]:
        name = state.get("name") or "?"
        add_folder(handle, ls(30053) % name, {"action": "profile"})
        add_folder(handle, ls(30030), {"action": "dashboard"})
        add_folder(handle, ls(30031), {"action": "history"})
        add_folder(handle, ls(30032), {"action": "watchlist"})
        add_folder(handle, ls(30033), {"action": "favorites"})
        add_folder(handle, ls(30034), {"action": "collection"})
        add_folder(handle, ls(30035), {"action": "ratings"})
        add_folder(handle, ls(30036), {"action": "lists"})
        add_folder(handle, ls(30037), {"action": "scrobbles"})
        add_folder(handle, ls(30038), {"action": "up_next"})
        add_folder(handle, ls(30057), {"action": "overlay_demo"})
        add_action_item(handle, ls(30003), {"action": "import_kodi"})
        add_action_item(handle, ls(30092), {"action": "open_dejavu"})
    else:
        if state["installed"]:
            add_action_item(handle, ls(30001), {"action": "open_dejavu"}, plot=ls(30091))
        add_folder(handle, ls(30057), {"action": "overlay_demo"})

    add_action_item(handle, ls(30004), {"action": "settings"})
    end_directory(handle, content="files")


def show_profile(handle, params):
    dv = _client(handle)
    if not dv:
        return
    result = dv.get_me()
    user, stats = unwrap_me(result)
    name = user.get("name") or user.get("username") or user.get("email") or "?"
    add_action_item(handle, "%s: %s" % (ls(30073), name), {"action": "home"})
    add_action_item(handle, ls(30075) % stats.get("watchlist", stats.get("watchlistCount", "—")), {"action": "watchlist"})
    add_action_item(handle, ls(30076) % stats.get("history", stats.get("historyCount", "—")), {"action": "history"})
    add_action_item(handle, ls(30077) % stats.get("lists", stats.get("listsCount", "—")), {"action": "lists"})
    add_action_item(handle, ls(30078) % stats.get("favorites", stats.get("favoritesCount", "—")), {"action": "favorites"})
    end_directory(handle, content="files")


def show_dashboard(handle, params):
    """RPC: get_dashboard() → one folder per widget."""
    dv = _client(handle)
    if not dv:
        return
    result = dv.get_dashboard()
    data = unwrap_data(result)
    widgets = []
    if isinstance(data, list):
        widgets = data
    elif isinstance(data, dict):
        widgets = data.get("widgets") or []
    if not widgets:
        notify(ls(30045) if result is not None else ls(30068), error=result is None)
        end_directory(handle)
        return
    for widget in widgets:
        if not isinstance(widget, dict):
            continue
        widget_type = widget.get("type") or widget.get("widget_type") or ""
        if widget_type in SKIP_WIDGET_TYPES:
            continue
        title = widget.get("title") or widget_type or ls(30030)
        props = widget.get("props") if isinstance(widget.get("props"), dict) else {}
        list_id = props.get("listId") or props.get("list_id") or widget.get("listId") or widget.get("list_id")
        folder_params = {"action": "dashboard_widget", "widget_type": widget_type}
        if list_id:
            folder_params["list_id"] = list_id
        add_folder(handle, title, folder_params)
    end_directory(handle, content="files")


def show_dashboard_widget(handle, params):
    """RPC: get_dashboard_widget(widget_type, list_id=..., page=...)."""
    dv = _client(handle)
    if not dv:
        return
    widget_type = params.get("widget_type") or ""
    if not widget_type:
        end_directory(handle)
        return
    result = dv.get_dashboard_widget(
        widget_type,
        list_id=params.get("list_id") or None,
        page=_page(params),
        page_size=page_size(),
        minimal=False,
    )
    _media_page(handle, result, {
        "action": "dashboard_widget",
        "widget_type": widget_type,
        "list_id": params.get("list_id") or "",
    })


def _filter_folders(action, current_type, types):
    folders = []
    if current_type:
        return folders
    for media_type, label_id in types:
        folders.append({
            "label": ls(label_id),
            "params": {"action": action, "type": media_type},
        })
    return folders


def show_history(handle, params):
    """RPC: get_history(media_type, page, page_size, sort)."""
    dv = _client(handle)
    if not dv:
        return
    media_type = params.get("type") or None
    for folder in _filter_folders("history", media_type, (
        ("movie", 30040),
        ("tv", 30041),
        ("episode", 30042),
    )):
        add_folder(handle, folder["label"], folder["params"])
    result = dv.get_history(
        media_type=media_type,
        page=_page(params),
        page_size=page_size(),
        sort="watchedAt:desc",
        minimal=False,
    )
    _media_page(handle, result, {"action": "history", "type": media_type or ""})


def show_watchlist(handle, params):
    """RPC: get_watchlist(media_type, page, page_size, sort)."""
    dv = _client(handle)
    if not dv:
        return
    media_type = params.get("type") or None
    for folder in _filter_folders("watchlist", media_type, (
        ("movie", 30040),
        ("tv", 30041),
    )):
        add_folder(handle, folder["label"], folder["params"])
    result = dv.get_watchlist(
        media_type=media_type,
        page=_page(params),
        page_size=page_size(),
        sort="addedAt:desc",
        minimal=False,
    )
    _media_page(handle, result, {"action": "watchlist", "type": media_type or ""})


def show_favorites(handle, params):
    """RPC: get_favorites(media_type, page, page_size)."""
    dv = _client(handle)
    if not dv:
        return
    media_type = params.get("type") or None
    for folder in _filter_folders("favorites", media_type, (
        ("movie", 30040),
        ("tv", 30041),
    )):
        add_folder(handle, folder["label"], folder["params"])
    result = dv.get_favorites(
        media_type=media_type,
        page=_page(params),
        page_size=page_size(),
        minimal=False,
    )
    _media_page(handle, result, {"action": "favorites", "type": media_type or ""})


def show_collection(handle, params):
    """RPC: get_collection(media_type, page, page_size, sort)."""
    dv = _client(handle)
    if not dv:
        return
    media_type = params.get("type") or None
    for folder in _filter_folders("collection", media_type, (
        ("movie", 30040),
        ("tv", 30041),
    )):
        add_folder(handle, folder["label"], folder["params"])
    result = dv.get_collection(
        media_type=media_type,
        page=_page(params),
        page_size=page_size(),
        sort="addedAt:desc",
        minimal=False,
    )
    _media_page(handle, result, {"action": "collection", "type": media_type or ""})


def show_ratings(handle, params):
    """RPC: get_ratings(media_type, page, page_size)."""
    dv = _client(handle)
    if not dv:
        return
    media_type = params.get("type") or None
    for folder in _filter_folders("ratings", media_type, (
        ("movie", 30040),
        ("tv", 30041),
    )):
        add_folder(handle, folder["label"], folder["params"])
    result = dv.get_ratings(
        media_type=media_type,
        page=_page(params),
        page_size=page_size(),
        minimal=False,
    )
    _media_page(handle, result, {"action": "ratings", "type": media_type or ""})


def show_lists(handle, params):
    """RPC: get_lists() → folders; each opens get_list_items(list_id)."""
    dv = _client(handle)
    if not dv:
        return
    result = dv.get_lists(page=_page(params), page_size=page_size(), minimal=False)
    if result is None:
        notify(ls(30068), error=True)
        end_directory(handle, content="files")
        return
    items, pagination = unwrap_list(result)
    for raw in items:
        if not isinstance(raw, dict):
            continue
        list_id = raw.get("id") or raw.get("list_id") or raw.get("listId")
        info = raw.get("info") if isinstance(raw.get("info"), dict) else {}
        name = raw.get("name") or info.get("title") or str(list_id or "")
        if not list_id:
            continue
        add_folder(handle, name, {"action": "list_items", "list_id": list_id})
    _next_page_folder(handle, {"action": "lists"}, pagination)
    if not items:
        add_action_item(handle, ls(30045), {"action": "home"})
    end_directory(handle, content="files")


def show_list_items(handle, params):
    """RPC: get_list_items(list_id, page, page_size)."""
    dv = _client(handle)
    if not dv:
        return
    list_id = params.get("list_id")
    if not list_id:
        end_directory(handle)
        return
    result = dv.get_list_items(
        list_id,
        page=_page(params),
        page_size=page_size(),
        minimal=False,
    )
    _media_page(handle, result, {"action": "list_items", "list_id": list_id})


def show_up_next(handle, params):
    """RPC: get_up_next(page, page_size)."""
    dv = _client(handle)
    if not dv:
        return
    result = dv.get_up_next(page=_page(params), page_size=page_size(), minimal=False)
    _media_page(handle, result, {"action": "up_next"})


def show_scrobbles(handle, params):
    """RPC: get_scrobbles(media_type, page, page_size) — continue watching."""
    dv = _client(handle)
    if not dv:
        return
    media_type = params.get("type") or None
    for folder in _filter_folders("scrobbles", media_type, (
        ("movie", 30040),
        ("episode", 30042),
    )):
        add_folder(handle, folder["label"], folder["params"])
    result = dv.get_scrobbles(
        media_type=media_type,
        page=_page(params),
        page_size=page_size(),
        minimal=False,
    )
    _media_page(handle, result, {"action": "scrobbles", "type": media_type or ""})


def show_overlay_demo(handle, params):
    """
    Hardcoded titles + get_media_status.

    This is the pattern vStream / AlkoFlix should copy on *their* list screens:
    collect TMDB ids, batch status (movie / tv / episode), set playcount + UniqueIDs.
    """
    add_action_item(handle, ls(30058), {"action": "home"})
    add_media_items(handle, DEMO_TITLES)
    end_directory(handle)
