# -*- coding: utf-8 -*-
"""
Copy-paste helper: talk to script.dejavu from another addon.

This is the integration surface documented in script.dejavu/README.md.
Do not call https://dejavu.plus from your addon. Do not copy api_client.py.
"""

import xbmc
import xbmcaddon


def user_display_name(user):
    """Best-effort label from a get_me() user dict."""
    if not isinstance(user, dict):
        return ""
    return (
        user.get("name")
        or user.get("username")
        or user.get("displayName")
        or user.get("email")
        or ""
    )


def script_session():
    """
    Read the dejaVu session from script.dejavu (no RPC).

    Source of truth is session.json (settings.xml can be overwritten by the
    Addon Settings dialog after Connect). Settings are a fallback.
    """
    if not xbmc.getCondVisibility("System.HasAddon(script.dejavu)"):
        return None
    token = ""
    username = ""
    try:
        import json
        import xbmcvfs
        path = xbmcvfs.translatePath(
            "special://profile/addon_data/script.dejavu/session.json"
        )
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle) or {}
        token = data.get("access_token") or ""
        username = data.get("username") or ""
    except Exception:
        pass
    try:
        script = xbmcaddon.Addon("script.dejavu")
    except Exception:
        if not token:
            return None
        return {"token": token, "username": username}
    return {
        "token": token or script.getSetting("access_token") or "",
        "username": username or script.getSetting("username") or "",
    }


def auth_state(timeout=5, probe_rpc=False):
    """
    How to know if the user is connected — copy this.

    There is ONE session: script.dejavu. Do not build a second login.

        session = xbmcaddon.Addon("script.dejavu")
        if session.getSetting("access_token"):
            name = session.getSetting("username")
            dv = get_dejavu()
            history = dv.get_history()   # RPC for *data*, not for auth

    If the user is not logged in, send them to script.dejavu:

        xbmc.executebuiltin("RunScript(script.dejavu,action=login)")

    Returns a dict:
      installed      — script.dejavu is present
      authenticated  — access_token in script.dejavu settings
      name           — username from those settings (or get_me if probe_rpc)
      user           — get_me() user dict if probe_rpc succeeded
      client         — DejaVuClient or None
      reachable      — True/False if probe_rpc, else None
    """
    session = script_session()
    if session is None:
        return {
            "installed": False,
            "authenticated": False,
            "name": "",
            "user": {},
            "client": None,
            "reachable": False,
        }

    authenticated = bool(session["token"])
    name = session["username"]
    dv = get_dejavu(timeout=timeout)
    user = {}
    reachable = None

    if probe_rpc and dv and authenticated:
        me = dv.get_me()
        if me is None:
            reachable = False
        else:
            reachable = True
            user, _stats = unwrap_me(me)
            name = user_display_name(user) or name or "?"

    if authenticated and not name:
        name = "?"

    return {
        "installed": True,
        "authenticated": authenticated,
        "name": name,
        "user": user,
        "client": dv,
        "reachable": reachable,
    }


def get_dejavu(timeout=5):
    """
    Return a DejaVuClient, or None if script.dejavu is missing.

    Guard the import so your addon still runs without dejaVu.
    Use timeout=8 for large get_media_status batches.
    """
    if not xbmc.getCondVisibility("System.HasAddon(script.dejavu)"):
        return None
    try:
        from client import DejaVuClient
        return DejaVuClient(timeout=timeout)
    except Exception:
        return None


def dejavu_flags(status, media_type, tmdb_id):
    """Pick data['movie:603'] (or tv:id) from a get_media_status response."""
    data = (status or {}).get("data") or {}
    if not isinstance(data, dict):
        return {}
    return data.get("%s:%s" % (media_type, tmdb_id)) or {}


def unwrap_data(result):
    """Return the `data` payload from a v1 `{success, data}` envelope."""
    if isinstance(result, dict) and "data" in result:
        return result.get("data")
    return result


def unwrap_list(result):
    """
    Normalize paginated RPC responses to (items, pagination).

    Full list payloads are already shaped for Kodi ListItems
    (info.title, art.poster, tmdbId, imdbId, …).
    """
    pagination = {}
    if not isinstance(result, dict):
        return [], pagination
    pagination = result.get("pagination") or {}
    data = result.get("data") if "data" in result else result
    if isinstance(data, list):
        return data, pagination
    if not isinstance(data, dict):
        return [], pagination
    pagination = data.get("pagination") or pagination
    for key in ("items", "results", "widgets", "lists", "history",
                "movies", "shows", "entries", "scrobbles"):
        value = data.get(key)
        if isinstance(value, list):
            return value, pagination
    inner = data.get("data")
    if isinstance(inner, list):
        return inner, pagination
    return [], pagination


def unwrap_me(result):
    """Return (user_dict, stats_dict) from get_me()."""
    if not isinstance(result, dict):
        return {}, {}
    user = result.get("user")
    stats = result.get("stats")
    data = result.get("data") if isinstance(result.get("data"), dict) else {}
    if not user:
        user = data.get("user") or data
    if not stats:
        stats = data.get("stats") or {}
    if not isinstance(user, dict):
        user = {}
    if not isinstance(stats, dict):
        stats = {}
    return user, stats


def rpc_ok(result):
    if result is None:
        return False
    if isinstance(result, dict) and result.get("success") is False:
        return False
    return True
